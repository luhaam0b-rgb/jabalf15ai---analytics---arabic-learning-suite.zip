
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Home from './pages/Home';
import Analysis from './pages/Analysis';
import Academy from './pages/Academy';
import Certification from './pages/Certification';
import Dashboard from './pages/Dashboard';
import Auth from './pages/Auth';
import { authService } from './services/auth';
import { AppLanguage, User, AuthState } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [language, setLanguage] = useState<AppLanguage>(AppLanguage.EN);
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    token: null,
    isAuthenticated: false,
    isLoading: true
  });

  // Handle Session persistence on mount
  useEffect(() => {
    const session = authService.getCurrentSession();
    if (session) {
      setAuthState({
        user: session.user,
        token: session.token,
        isAuthenticated: true,
        isLoading: false
      });
    } else {
      setAuthState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const handleAuthSuccess = (user: User, token: string) => {
    setAuthState({
      user,
      token,
      isAuthenticated: true,
      isLoading: false
    });
    setActiveTab('home');
  };

  const handleLogout = () => {
    authService.logout();
    setAuthState({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false
    });
    setActiveTab('home');
  };

  const renderContent = () => {
    if (authState.isLoading) {
      return (
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-12 h-12 border-4 border-amber-900/30 border-t-amber-500 rounded-full animate-spin"></div>
        </div>
      );
    }

    if (!authState.isAuthenticated) {
      return <Auth onAuthSuccess={handleAuthSuccess} language={language} />;
    }

    switch (activeTab) {
      case 'home':
        return <Home onStart={setActiveTab} language={language} />;
      case 'analysis':
        return <Analysis language={language} />;
      case 'academy':
        return <Academy language={language} />;
      case 'certification':
        return <Certification language={language} />;
      case 'dashboard':
        return <Dashboard language={language} user={authState.user!} />;
      default:
        return <Home onStart={setActiveTab} language={language} />;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      language={language} 
      setLanguage={setLanguage}
      user={authState.user}
      onLogout={handleLogout}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
