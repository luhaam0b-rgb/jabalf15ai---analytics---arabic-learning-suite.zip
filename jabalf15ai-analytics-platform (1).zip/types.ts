
export enum AppLanguage {
  EN = 'en',
  AR = 'ar'
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  rank: string;
  joinedAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface UserProgress {
  userId: string;
  completedLessons: string[];
  quizScores: Record<string, number>;
  certifications: Certification[];
}

export interface Certification {
  id: string;
  courseTitle: string;
  score: number;
  issuedAt: string;
  verificationCode: string;
  userName: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface AnalysisResult {
  summary: string;
  suggestedDAX: { name: string; formula: string; description: string }[];
  visualRecommendations: string[];
}
