
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, QuizQuestion } from "../types";

// Always use the specified initialization pattern for GoogleGenAI
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDataInsights = async (csvSnippet: string, fileName: string): Promise<AnalysisResult> => {
  const prompt = `Analyze this dataset snippet from file '${fileName}':\n${csvSnippet}\n
  Provide:
  1. A high-level executive summary of the data.
  2. 3 powerful Power BI DAX measures that would provide deep insights.
  3. Recommendation for the best 3 visualizations to use in a dashboard.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          suggestedDAX: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                formula: { type: Type.STRING },
                description: { type: Type.STRING }
              }
            }
          },
          visualRecommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["summary", "suggestedDAX", "visualRecommendations"]
      }
    }
  });

  // Directly access the text property as per guidelines
  return JSON.parse(response.text || "{}");
};

export const generateQuiz = async (topic: string): Promise<QuizQuestion[]> => {
  const prompt = `Generate a high-level 5-question quiz for the topic: ${topic}. 
  The questions should be challenging (Advanced Level).`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.INTEGER },
            explanation: { type: Type.STRING }
          },
          required: ["id", "question", "options", "correctAnswer", "explanation"]
        }
      }
    }
  });

  // Directly access the text property as per guidelines
  return JSON.parse(response.text || "[]");
};

export const getTutorialContent = async (topic: string): Promise<string> => {
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Create a detailed data analytics tutorial about ${topic} in Markdown format. Include examples and best practices. Use a professional tone.`,
    });
    // Directly access the text property
    return response.text || "";
};
