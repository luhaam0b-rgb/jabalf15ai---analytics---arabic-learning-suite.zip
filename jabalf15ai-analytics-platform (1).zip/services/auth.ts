
import { User } from '../types';

/**
 * A sophisticated mock authentication service simulating a JWT-based provider (like Auth0/Firebase).
 * In a production environment, this would interface with an OIDC provider.
 */

const TOKEN_KEY = 'jabalf15ai_token';
const USER_KEY = 'jabalf15ai_user';

// Utility to simulate JWT structure: header.payload.signature
const generateMockJWT = (payload: object) => {
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = btoa(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + 3600 }));
  const signature = "mock_signature_for_jabalf15ai";
  return `${header}.${body}.${signature}`;
};

export const authService = {
  login: async (email: string, password: string): Promise<{ user: User; token: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1200));

    // For demo purposes, we accept any valid email format
    const mockUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
      rank: "Gold I",
      joinedAt: new Date().toISOString()
    };

    const token = generateMockJWT(mockUser);
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(mockUser));

    return { user: mockUser, token };
  },

  register: async (name: string, email: string, password: string): Promise<{ user: User; token: string }> => {
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      name,
      rank: "Bronze I",
      joinedAt: new Date().toISOString()
    };

    const token = generateMockJWT(newUser);
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(newUser));

    return { user: newUser, token };
  },

  logout: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },

  getCurrentSession: (): { user: User; token: string } | null => {
    const token = localStorage.getItem(TOKEN_KEY);
    const userStr = localStorage.getItem(USER_KEY);
    if (token && userStr) {
      try {
        return { user: JSON.parse(userStr), token };
      } catch {
        return null;
      }
    }
    return null;
  }
};
