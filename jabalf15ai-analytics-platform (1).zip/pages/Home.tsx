
import React from 'react';
import { ArrowRight, Database, ShieldCheck, Zap } from 'lucide-react';
import { AppLanguage } from '../types';

interface HomeProps {
  onStart: (tab: string) => void;
  language: AppLanguage;
}

const Home: React.FC<HomeProps> = ({ onStart, language }) => {
  const isEn = language === AppLanguage.EN;

  return (
    <div className="space-y-16 animate-in fade-in duration-700">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden rounded-3xl bg-neutral-900/50 border border-amber-900/20">
        <div className="absolute inset-0 gold-gradient opacity-5 pointer-events-none"></div>
        <div className="relative z-10 text-center px-4">
          <h1 className="text-4xl md:text-6xl font-cinzel font-bold mb-6 tracking-tight">
            <span className="block text-white">
              {isEn ? 'Master the Art of' : 'أتقن فن'}
            </span>
            <span className="gold-text">
              {isEn ? 'Advanced Data Analytics' : 'تحليلات البيانات المتقدمة'}
            </span>
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            {isEn 
              ? 'The elite platform for data science education, automated analysis, and professional certification. Empower your decision-making with JABALF15AI.'
              : 'المنصة النخبوية لتعليم علوم البيانات، والتحليل الآلي، والاعتماد المهني. عزز اتخاذك للقرارات مع جبل F15.'}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button 
              onClick={() => onStart('analysis')}
              className="px-8 py-4 gold-gradient text-black font-bold rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(179,135,40,0.3)]"
            >
              {isEn ? 'Start AI Analysis' : 'ابدأ تحليل الذكاء الاصطناعي'} <ArrowRight size={20} />
            </button>
            <button 
              onClick={() => onStart('academy')}
              className="px-8 py-4 bg-white/5 border border-amber-500/30 text-amber-500 font-bold rounded-lg hover:bg-white/10 transition-all"
            >
              {isEn ? 'Explore Academy' : 'استكشف الأكاديمية'}
            </button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="grid md:grid-cols-3 gap-8">
        {[
          {
            icon: Database,
            title: isEn ? 'Smart Analytics' : 'تحليلات ذكية',
            desc: isEn ? 'Instant CSV/XLSX insights using state-of-the-art Generative AI models.' : 'رؤى فورية لملفات البيانات باستخدام أحدث نماذج الذكاء الاصطناعي التوليدي.'
          },
          {
            icon: Zap,
            title: isEn ? 'Pro DAX Engine' : 'محرك DAX احترافي',
            desc: isEn ? 'Generate complex Power BI measures and visualization strategies in seconds.' : 'أنشئ مقاييس Power BI المعقدة واستراتيجيات التصور في ثوانٍ.'
          },
          {
            icon: ShieldCheck,
            title: isEn ? 'Secure Credentials' : 'اعتمادات آمنة',
            desc: isEn ? 'Verify your skills with blockchain-inspired certification and verifiable IDs.' : 'تحقق من مهاراتك بشهادات مستوحاة من البلوكشين ومعرفات قابلة للتحقق.'
          }
        ].map((feature, i) => (
          <div key={i} className="p-8 rounded-2xl bg-neutral-900 border border-amber-900/10 hover:border-amber-500/40 transition-colors group">
            <div className="w-12 h-12 gold-gradient rounded-lg flex items-center justify-center mb-6 text-black group-hover:scale-110 transition-transform">
              <feature.icon size={24} />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
            <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
          </div>
        ))}
      </section>

      {/* Stats Section */}
      <section className="bg-black/40 py-12 px-8 rounded-2xl border-x border-amber-500/20 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
        <div>
          <div className="text-3xl font-cinzel gold-text font-bold">15K+</div>
          <div className="text-gray-500 text-sm mt-1">{isEn ? 'Active Students' : 'طالب نشط'}</div>
        </div>
        <div>
          <div className="text-3xl font-cinzel gold-text font-bold">850k</div>
          <div className="text-gray-500 text-sm mt-1">{isEn ? 'Analyses Run' : 'تحليل منجز'}</div>
        </div>
        <div>
          <div className="text-3xl font-cinzel gold-text font-bold">200+</div>
          <div className="text-gray-500 text-sm mt-1">{isEn ? 'Tutorials' : 'درس تعليمي'}</div>
        </div>
        <div>
          <div className="text-3xl font-cinzel gold-text font-bold">99.9%</div>
          <div className="text-gray-500 text-sm mt-1">{isEn ? 'SLA Uptime' : 'وقت التشغيل'}</div>
        </div>
      </section>
    </div>
  );
};

export default Home;
