
import React, { useState, useEffect } from 'react';
import { Book, PlayCircle, Clock, ChevronRight, Loader2, Search } from 'lucide-react';
import { getTutorialContent } from '../services/gemini';
import { AppLanguage } from '../types';

interface AcademyProps {
    language: AppLanguage;
}

const TOPICS = [
  { id: 'power-bi', title: 'Power BI Advanced', level: 'Intermediate', duration: '45m', color: 'bg-yellow-500' },
  { id: 'dax-fundamentals', title: 'DAX Deep Dive', level: 'Advanced', duration: '1h 20m', color: 'bg-amber-600' },
  { id: 'data-storytelling', title: 'Data Storytelling', level: 'Beginner', duration: '30m', color: 'bg-orange-500' },
  { id: 'sql-analytics', title: 'SQL for Analytics', level: 'Advanced', duration: '2h', color: 'bg-amber-800' },
];

const Academy: React.FC<AcademyProps> = ({ language }) => {
  const [selectedTopic, setSelectedTopic] = useState<typeof TOPICS[0] | null>(null);
  const [content, setContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const isEn = language === AppLanguage.EN;

  useEffect(() => {
    if (selectedTopic) {
      loadContent(selectedTopic.title);
    }
  }, [selectedTopic]);

  const loadContent = async (topic: string) => {
    setIsLoading(true);
    try {
      const markdown = await getTutorialContent(topic);
      setContent(markdown);
    } catch (err) {
      setContent('# Error\nFailed to load content.');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredTopics = TOPICS.filter(t => t.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-cinzel font-bold gold-text">JABALF15AI Academy</h2>
          <p className="text-gray-400 mt-2">{isEn ? 'Elite education for modern data professionals.' : 'تعليم نخبة لمهنيي البيانات العصريين.'}</p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input
            type="text"
            placeholder={isEn ? "Search topics..." : "ابحث في المواضيع..."}
            className="pl-10 pr-4 py-3 bg-neutral-900 border border-amber-900/30 rounded-xl focus:outline-none focus:border-amber-500 text-gray-200 min-w-[300px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {!selectedTopic ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredTopics.map((topic) => (
            <div 
              key={topic.id}
              onClick={() => setSelectedTopic(topic)}
              className="bg-neutral-900 rounded-2xl border border-amber-900/10 p-6 cursor-pointer hover:border-amber-500/50 transition-all group overflow-hidden relative"
            >
              <div className={`absolute top-0 right-0 w-24 h-24 ${topic.color} opacity-5 -translate-y-12 translate-x-12 rounded-full`}></div>
              <div className="flex flex-col h-full">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-6 text-white ${topic.color}`}>
                  <Book size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-500 transition-colors">{topic.title}</h3>
                <div className="mt-auto flex items-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1"><PlayCircle size={14} /> {topic.level}</span>
                  <span className="flex items-center gap-1"><Clock size={14} /> {topic.duration}</span>
                </div>
                <div className="mt-6 flex items-center text-amber-500 font-bold text-sm uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">
                  {isEn ? 'Begin Learning' : 'ابدأ التعلم'} <ChevronRight size={16} className="ml-1 rtl:rotate-180" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-neutral-900 rounded-3xl border border-amber-900/20 overflow-hidden">
          <div className="p-6 bg-black/40 border-b border-amber-900/20 flex items-center justify-between">
            <button 
              onClick={() => setSelectedTopic(null)}
              className="text-amber-500 hover:underline flex items-center gap-2"
            >
              <ChevronRight size={18} className="rotate-180 rtl:rotate-0" /> {isEn ? 'Back to Academy' : 'العودة إلى الأكاديمية'}
            </button>
            <div className="flex items-center gap-4">
               <span className="bg-amber-900/30 text-amber-500 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">{selectedTopic.level}</span>
            </div>
          </div>
          
          <div className="p-8 md:p-12 min-h-[500px]">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center gap-4 text-gray-500 py-20">
                <Loader2 className="animate-spin text-amber-500" size={48} />
                <p className="animate-pulse">{isEn ? 'Generating dynamic content...' : 'جاري إنشاء المحتوى الديناميكي...'}</p>
              </div>
            ) : (
              <div className="prose prose-invert prose-amber max-w-none">
                {/* Simple manual rendering for simulation, normally use a library like react-markdown */}
                {content.split('\n').map((line, i) => {
                  if (line.startsWith('# ')) return <h1 key={i} className="text-3xl font-cinzel gold-text mb-6 mt-10">{line.replace('# ', '')}</h1>;
                  if (line.startsWith('## ')) return <h2 key={i} className="text-2xl font-cinzel text-amber-500 mb-4 mt-8">{line.replace('## ', '')}</h2>;
                  if (line.startsWith('### ')) return <h3 key={i} className="text-xl font-bold text-white mb-3 mt-6">{line.replace('### ', '')}</h3>;
                  if (line.startsWith('- ')) return <li key={i} className="text-gray-300 ml-4 rtl:mr-4 mb-2">{line.replace('- ', '')}</li>;
                  return <p key={i} className="text-gray-400 leading-relaxed mb-4">{line}</p>;
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Academy;
