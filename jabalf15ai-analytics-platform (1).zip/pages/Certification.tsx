
import React, { useState } from 'react';
import { generateQuiz } from '../services/gemini';
import { QuizQuestion, AppLanguage } from '../types';
import { Award, CheckCircle2, Trophy, Loader2, RefreshCcw, Download } from 'lucide-react';

interface CertificationProps {
    language: AppLanguage;
}

const Certification: React.FC<CertificationProps> = ({ language }) => {
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [quiz, setQuiz] = useState<QuizQuestion[] | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [userName, setUserName] = useState('');

  const isEn = language === AppLanguage.EN;

  const handleStartQuiz = async () => {
    if (!topic || !userName) return;
    setIsGenerating(true);
    try {
      const q = await generateQuiz(topic);
      setQuiz(q);
      setAnswers({});
      setIsSubmitted(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const score = quiz ? Math.round((Object.entries(answers).filter(([id, idx]) => {
    const q = quiz.find(item => item.id === id);
    return q?.correctAnswer === idx;
  }).length / quiz.length) * 100) : 0;

  const passed = score >= 80;

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in duration-500">
      {!quiz && !isSubmitted ? (
        <div className="space-y-8">
          <div className="text-center space-y-4">
             <div className="w-20 h-20 gold-gradient rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(179,135,40,0.4)]">
                <Award className="text-black" size={40} />
             </div>
             <h2 className="text-3xl font-cinzel font-bold gold-text">{isEn ? 'Professional Certification' : 'الاعتماد المهني'}</h2>
             <p className="text-gray-400">{isEn ? 'Prove your expertise and earn a verified industry credential.' : 'أثبت خبرتك واحصل على اعتماد صناعي موثق.'}</p>
          </div>

          <div className="bg-neutral-900 p-8 rounded-3xl border border-amber-900/30 space-y-6">
            <div>
              <label className="block text-gray-400 text-sm mb-2 uppercase tracking-widest">{isEn ? 'Full Name' : 'الاسم الكامل'}</label>
              <input 
                type="text" 
                className="w-full bg-black/50 border border-amber-900/30 rounded-xl px-4 py-3 text-white focus:border-amber-500 focus:outline-none"
                placeholder={isEn ? "As it should appear on certificate" : "كما يجب أن يظهر في الشهادة"}
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-gray-400 text-sm mb-2 uppercase tracking-widest">{isEn ? 'Certification Topic' : 'موضوع الشهادة'}</label>
              <select 
                className="w-full bg-black/50 border border-amber-900/30 rounded-xl px-4 py-3 text-white focus:border-amber-500 focus:outline-none"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
              >
                <option value="">{isEn ? "-- Select Path --" : "-- اختر المسار --"}</option>
                <option value="Advanced Power BI & DAX">Advanced Power BI & DAX</option>
                <option value="SQL for Data Science">SQL for Data Science</option>
                <option value="Business Intelligence Strategy">Business Intelligence Strategy</option>
                <option value="Python for Analytics">Python for Analytics</option>
              </select>
            </div>
            <button 
              onClick={handleStartQuiz}
              disabled={isGenerating || !topic || !userName}
              className="w-full py-4 gold-gradient text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] transition-transform disabled:opacity-50"
            >
              {isGenerating ? <><Loader2 className="animate-spin" /> {isEn ? 'Generating Quiz...' : 'جاري إنشاء الاختبار...'}</> : (isEn ? 'Begin Examination' : 'بدء الاختبار')}
            </button>
          </div>
        </div>
      ) : quiz && !isSubmitted ? (
        <div className="space-y-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-cinzel font-bold text-amber-500">{topic}</h3>
            <div className="text-gray-400">{isEn ? 'Question' : 'سؤال'} {Object.keys(answers).length} / {quiz.length}</div>
          </div>

          <div className="space-y-12">
            {quiz.map((q, qIdx) => (
              <div key={q.id} className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/10">
                <p className="text-xl text-white font-medium mb-6">
                  <span className="text-amber-500 mr-2">{qIdx + 1}.</span> {q.question}
                </p>
                <div className="grid gap-4">
                  {q.options.map((opt, oIdx) => (
                    <button
                      key={oIdx}
                      onClick={() => setAnswers({...answers, [q.id]: oIdx})}
                      className={`p-4 rounded-xl border text-left transition-all flex items-center gap-4 ${
                        answers[q.id] === oIdx 
                        ? 'border-amber-500 bg-amber-900/20 text-white' 
                        : 'border-amber-900/30 bg-black/40 text-gray-400 hover:border-amber-500/50'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center ${answers[q.id] === oIdx ? 'border-amber-500 bg-amber-500' : 'border-gray-600'}`}>
                        {answers[q.id] === oIdx && <div className="w-2 h-2 bg-black rounded-full" />}
                      </div>
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setIsSubmitted(true)}
            className="w-full py-5 gold-gradient text-black font-bold rounded-2xl shadow-xl hover:scale-105 transition-all mt-10"
          >
            {isEn ? 'Submit Final Answers' : 'إرسال الإجابات النهائية'}
          </button>
        </div>
      ) : (
        <div className="text-center space-y-12 animate-in zoom-in duration-700">
          <div className="space-y-4">
            <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center ${passed ? 'bg-green-900/20 text-green-500' : 'bg-red-900/20 text-red-500'}`}>
              {passed ? <Trophy size={48} /> : <RefreshCcw size={48} />}
            </div>
            <h2 className="text-4xl font-cinzel font-bold text-white">
              {passed ? (isEn ? 'Congratulations!' : 'تهانينا!') : (isEn ? 'Keep Practicing' : 'استمر في الممارسة')}
            </h2>
            <div className="text-6xl font-cinzel gold-text font-bold">{score}%</div>
            <p className="text-gray-400 max-w-md mx-auto">
              {passed 
                ? (isEn ? `You have successfully demonstrated mastery in ${topic}.` : `لقد أظهرت بنجاح إتقانك في ${topic}.`)
                : (isEn ? 'You need 80% or higher to earn the certification.' : 'تحتاج إلى 80٪ أو أكثر للحصول على الشهادة.')
              }
            </p>
          </div>

          {passed && (
            <div className="p-1 border-[12px] gold-border bg-neutral-900 aspect-[1.414/1] w-full max-w-2xl mx-auto shadow-2xl relative overflow-hidden text-center flex flex-col items-center justify-center gap-6 py-12 px-8">
              <div className="absolute inset-0 gold-gradient opacity-5 pointer-events-none"></div>
              <div className="font-cinzel text-amber-500 text-sm tracking-[0.3em] uppercase">{isEn ? 'Certificate of Completion' : 'شهادة إتمام'}</div>
              <div className="w-16 h-1 bg-amber-500/50"></div>
              <div>
                <p className="text-gray-500 text-xs italic mb-2">{isEn ? 'This is to certify that' : 'نشهد بأن'}</p>
                <h3 className="text-4xl font-cinzel gold-text font-bold mb-4">{userName}</h3>
                <p className="text-gray-400 max-w-sm">{isEn ? `has successfully completed all requirements for the professional certification in` : `قد أتم بنجاح جميع المتطلبات للحصول على الاعتماد المهني في`}</p>
                <div className="text-xl font-bold text-white mt-4">{topic}</div>
              </div>
              <div className="flex justify-between w-full mt-8 px-4">
                <div className="text-left">
                  <div className="text-[10px] text-gray-500 uppercase tracking-widest">{isEn ? 'Date' : 'التاريخ'}</div>
                  <div className="text-xs text-white border-t border-amber-900/50 mt-1 pt-1">{new Date().toLocaleDateString()}</div>
                </div>
                <div className="w-16 h-16 gold-gradient rounded-full flex items-center justify-center border-4 border-black rotate-12 shadow-lg">
                  <Award size={32} className="text-black" />
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-gray-500 uppercase tracking-widest">{isEn ? 'Verification' : 'التحقق'}</div>
                  <div className="text-xs text-white border-t border-amber-900/50 mt-1 pt-1">JBAL-{(Math.random()*1000000).toFixed(0)}</div>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-4 justify-center">
            {passed && (
              <button 
                onClick={() => window.print()}
                className="px-8 py-3 bg-amber-500 text-black font-bold rounded-lg flex items-center gap-2 hover:bg-amber-400 transition-all"
              >
                <Download size={18} /> {isEn ? 'Download PDF' : 'تحميل PDF'}
              </button>
            )}
            <button 
              onClick={() => {setQuiz(null); setIsSubmitted(false); setAnswers({}); setTopic('');}}
              className="px-8 py-3 bg-white/5 border border-amber-900/30 text-amber-500 font-bold rounded-lg"
            >
              {isEn ? 'Try Different Topic' : 'تجربة موضوع آخر'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Certification;
