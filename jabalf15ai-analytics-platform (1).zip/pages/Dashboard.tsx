
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { Target, TrendingUp, Users, Calendar, Activity, Zap, Award } from 'lucide-react';
import { AppLanguage, User } from '../types';

interface DashboardProps {
    language: AppLanguage;
    user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ language, user }) => {
  const isEn = language === AppLanguage.EN;

  const data = [
    { name: 'Mon', score: 40 },
    { name: 'Tue', score: 30 },
    { name: 'Wed', score: 65 },
    { name: 'Thu', score: 45 },
    { name: 'Fri', score: 90 },
    { name: 'Sat', score: 70 },
    { name: 'Sun', score: 85 },
  ];

  const topicsData = [
    { name: 'Power BI', value: 85 },
    { name: 'SQL', value: 65 },
    { name: 'Python', value: 45 },
    { name: 'Statistics', value: 92 },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-cinzel font-bold gold-text">
            {isEn ? `Welcome, ${user.name}` : `مرحباً، ${user.name}`}
          </h2>
          <p className="text-gray-500 mt-1">{isEn ? 'Your professional growth at a glance' : 'نظرة سريعة على نموك المهني'}</p>
        </div>
        <div className="flex items-center gap-4 bg-neutral-900 p-2 pr-4 pl-4 rounded-full border border-amber-900/20">
          <div className="text-xs text-gray-500 uppercase tracking-widest">{isEn ? 'Status:' : 'الحالة:'}</div>
          <div className="text-amber-500 font-cinzel font-bold text-sm tracking-widest">{user.rank}</div>
          <div className="h-4 w-px bg-amber-900/30"></div>
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <Calendar size={14} /> {new Date().toLocaleDateString()}
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Target, label: isEn ? 'Rank' : 'الرتبة', val: user.rank, color: 'text-amber-500' },
          { icon: Zap, label: isEn ? 'Streak' : 'النشاط', val: '12 Days', color: 'text-orange-500' },
          { icon: Activity, label: isEn ? 'Avg Score' : 'معدل الدرجات', val: '88%', color: 'text-blue-500' },
          { icon: TrendingUp, label: isEn ? 'Growth' : 'النمو', val: '+24%', color: 'text-green-500' },
        ].map((m, i) => (
          <div key={i} className="bg-neutral-900 p-6 rounded-2xl border border-amber-900/10 group hover:border-amber-500/30 transition-all">
            <m.icon className={`mb-4 ${m.color}`} size={24} />
            <div className="text-xs text-gray-500 uppercase tracking-widest">{m.label}</div>
            <div className="text-xl font-cinzel font-bold text-white mt-1">{m.val}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Weekly Progress */}
        <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/10">
          <h3 className="text-lg font-cinzel font-bold text-white mb-8">{isEn ? 'Learning Momentum' : 'زخم التعلم'}</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#b38728" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#b38728" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="name" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111', border: '1px solid #b38728', borderRadius: '8px' }}
                  itemStyle={{ color: '#b38728' }}
                />
                <Area type="monotone" dataKey="score" stroke="#b38728" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Skill Matrix */}
        <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/10">
          <h3 className="text-lg font-cinzel font-bold text-white mb-8">{isEn ? 'Topic Proficiency' : 'كفاءة المواضيع'}</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topicsData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#333" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" stroke="#999" width={80} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111', border: '1px solid #b38728', borderRadius: '8px' }}
                  cursor={{fill: 'rgba(255,255,255,0.05)'}}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {topicsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#b38728' : '#6b4c10'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* User Info & Recent Achievements */}
      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/10 md:col-span-1">
          <h3 className="text-lg font-cinzel font-bold text-white mb-6">{isEn ? 'Identity' : 'الهوية'}</h3>
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 gold-gradient rounded-full flex items-center justify-center text-4xl font-bold text-black mb-4 shadow-xl">
              {user.name.charAt(0)}
            </div>
            <div className="text-xl font-bold text-white">{user.name}</div>
            <div className="text-gray-500 text-sm mb-6">{user.email}</div>
            
            <div className="w-full space-y-4">
              <div className="flex justify-between text-xs uppercase tracking-widest text-gray-500">
                <span>{isEn ? 'Member Since' : 'عضو منذ'}</span>
                <span className="text-white">{new Date(user.joinedAt).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between text-xs uppercase tracking-widest text-gray-500">
                <span>{isEn ? 'User ID' : 'معرف المستخدم'}</span>
                <span className="text-amber-500 font-mono">{user.id}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/10 md:col-span-2">
           <h3 className="text-lg font-cinzel font-bold text-white mb-6">{isEn ? 'Recent Milestones' : 'الإنجازات الأخيرة'}</h3>
           <div className="space-y-4">
              {[
                { title: isEn ? 'Master of DAX' : 'خبير DAX', date: '2 days ago', icon: Award },
                { title: isEn ? '10 Day Streak' : 'نشاط لمدة 10 أيام', date: 'Yesterday', icon: Zap },
                { title: isEn ? 'First AI Analysis' : 'أول تحليل ذكي', date: 'Today', icon: Activity },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5 hover:border-amber-500/30 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-amber-900/20 rounded flex items-center justify-center text-amber-500">
                      <item.icon size={20} />
                    </div>
                    <div>
                      <div className="text-white font-medium">{item.title}</div>
                      <div className="text-xs text-gray-500">{item.date}</div>
                    </div>
                  </div>
                  <div className="text-amber-500 font-bold text-sm">+50 XP</div>
                </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
