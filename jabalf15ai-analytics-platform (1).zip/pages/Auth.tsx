
import React, { useState } from 'react';
import { User, Mail, Lock, LogIn, UserPlus, BrainCircuit, AlertCircle } from 'lucide-react';
import { authService } from '../services/auth';
import { AppLanguage } from '../types';

interface AuthProps {
  onAuthSuccess: (user: any, token: string) => void;
  language: AppLanguage;
}

const Auth: React.FC<AuthProps> = ({ onAuthSuccess, language }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isEn = language === AppLanguage.EN;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      let result;
      if (isLogin) {
        result = await authService.login(email, password);
      } else {
        result = await authService.register(name, email, password);
      }
      onAuthSuccess(result.user, result.token);
    } catch (err) {
      setError(isEn ? "Authentication failed. Please try again." : "فشل التحقق من الهوية. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 animate-in fade-in zoom-in duration-500">
      <div className="max-w-md w-full space-y-8 bg-neutral-900/80 p-10 rounded-3xl border border-amber-900/30 backdrop-blur-xl shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-1 gold-gradient"></div>
        
        <div className="text-center">
          <div className="mx-auto w-16 h-16 gold-gradient rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(179,135,40,0.4)]">
            <BrainCircuit className="text-black" size={32} />
          </div>
          <h2 className="mt-6 text-3xl font-cinzel font-bold gold-text uppercase tracking-widest">
            {isLogin 
              ? (isEn ? "Welcome Back" : "مرحباً بعودتك") 
              : (isEn ? "Join the Elite" : "انضم إلى النخبة")}
          </h2>
          <p className="mt-2 text-sm text-gray-500 font-medium">
            {isLogin 
              ? (isEn ? "Access your advanced data portal" : "ادخل إلى بوابة البيانات المتقدمة")
              : (isEn ? "Start your certification journey" : "ابدأ رحلة الاعتماد الخاصة بك")}
          </p>
        </div>

        <div className="mt-8 flex bg-black/40 p-1 rounded-xl border border-amber-900/20">
          <button 
            onClick={() => setIsLogin(true)}
            className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${isLogin ? 'gold-gradient text-black' : 'text-gray-500'}`}
          >
            {isEn ? "Login" : "تسجيل الدخول"}
          </button>
          <button 
            onClick={() => setIsLogin(false)}
            className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${!isLogin ? 'gold-gradient text-black' : 'text-gray-500'}`}
          >
            {isEn ? "Register" : "تسجيل"}
          </button>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-900/20 border border-red-900/50 text-red-400 p-3 rounded-lg flex items-center gap-2 text-sm animate-shake">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          <div className="space-y-4">
            {!isLogin && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                  <User size={18} />
                </div>
                <input
                  required
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 bg-black/50 border border-amber-900/30 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-amber-500 transition-colors"
                  placeholder={isEn ? "Full Name" : "الاسم الكامل"}
                />
              </div>
            )}
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                <Mail size={18} />
              </div>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 bg-black/50 border border-amber-900/30 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-amber-500 transition-colors"
                placeholder={isEn ? "Email Address" : "البريد الإلكتروني"}
              />
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                <Lock size={18} />
              </div>
              <input
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 bg-black/50 border border-amber-900/30 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-amber-500 transition-colors"
                placeholder={isEn ? "Password" : "كلمة المرور"}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="group relative w-full flex justify-center py-4 px-4 border border-transparent text-sm font-bold rounded-xl gold-gradient text-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 shadow-lg hover:brightness-110 transition-all disabled:opacity-50"
          >
            <span className="absolute left-0 inset-y-0 flex items-center pl-3">
              {isLogin ? <LogIn className="text-black/60" size={18} /> : <UserPlus className="text-black/60" size={18} />}
            </span>
            {isLoading 
              ? (isEn ? "Processing..." : "جاري المعالجة...") 
              : (isLogin 
                ? (isEn ? "SIGN IN" : "تسجيل الدخول") 
                : (isEn ? "CREATE ACCOUNT" : "إنشاء حساب"))
            }
          </button>
        </form>
      </div>
    </div>
  );
};

export default Auth;
