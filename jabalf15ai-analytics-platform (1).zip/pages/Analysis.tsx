
import React, { useState } from 'react';
import { Upload, FileText, Sparkles, AlertCircle, Copy, Check, BarChart4 } from 'lucide-react';
import { generateDataInsights } from '../services/gemini';
import { AnalysisResult, AppLanguage } from '../types';

interface AnalysisProps {
    language: AppLanguage;
}

const Analysis: React.FC<AnalysisProps> = ({ language }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const isEn = language === AppLanguage.EN;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type === 'text/csv' || selectedFile.name.endsWith('.csv')) {
        setFile(selectedFile);
        setError(null);
      } else {
        setError(isEn ? 'Please upload a CSV file.' : 'يرجى تحميل ملف CSV.');
      }
    }
  };

  const runAnalysis = async () => {
    if (!file) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const text = await file.text();
      const snippet = text.slice(0, 5000); // Send first 5k characters
      const insights = await generateDataInsights(snippet, file.name);
      setResult(insights);
    } catch (err) {
      setError(isEn ? 'Failed to analyze data. Please check your API key.' : 'فشل تحليل البيانات. يرجى التحقق من مفتاح API الخاص بك.');
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom duration-500">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-cinzel font-bold gold-text">{isEn ? 'AI Data Architect' : 'مهندس البيانات بالذكاء الاصطناعي'}</h2>
        <p className="text-gray-400">{isEn ? 'Upload your dataset and let JABALF15AI architect your dashboard strategy.' : 'قم بتحميل مجموعة بياناتك ودع JABALF15AI يصمم استراتيجية لوحة المعلومات الخاصة بك.'}</p>
      </div>

      {!result ? (
        <div className="bg-neutral-900 border-2 border-dashed border-amber-900/30 rounded-3xl p-12 text-center transition-all hover:border-amber-500/50">
          <input
            type="file"
            id="file-upload"
            className="hidden"
            accept=".csv"
            onChange={handleFileUpload}
          />
          <label htmlFor="file-upload" className="cursor-pointer space-y-4 block">
            <div className="w-16 h-16 bg-amber-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Upload className="text-amber-500" size={32} />
            </div>
            {file ? (
              <div className="space-y-2">
                <p className="text-amber-400 font-bold text-lg">{file.name}</p>
                <p className="text-gray-500 text-sm">{(file.size / 1024).toFixed(2)} KB</p>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-xl font-medium text-white">{isEn ? 'Click to upload your CSV' : 'انقر لتحميل ملف CSV الخاص بك'}</p>
                <p className="text-gray-500">{isEn ? 'Maximum file size: 10MB' : 'أقصى حجم للملف: 10 ميجابايت'}</p>
              </div>
            )}
          </label>

          {file && (
            <button
              onClick={runAnalysis}
              disabled={isAnalyzing}
              className={`mt-8 px-10 py-4 gold-gradient text-black font-bold rounded-xl flex items-center justify-center gap-3 mx-auto transition-all ${isAnalyzing ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 shadow-[0_0_20px_rgba(179,135,40,0.4)]'}`}
            >
              {isAnalyzing ? (
                <>
                  <Sparkles className="animate-spin" size={20} />
                  {isEn ? 'Analyzing Patterns...' : 'جاري تحليل الأنماط...'}
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  {isEn ? 'Execute Intelligent Analysis' : 'تنفيذ التحليل الذكي'}
                </>
              )}
            </button>
          )}

          {error && (
            <div className="mt-6 flex items-center justify-center gap-2 text-red-400 bg-red-900/10 p-4 rounded-lg">
              <AlertCircle size={20} />
              {error}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in zoom-in duration-500">
          {/* Executive Summary */}
          <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/20">
            <h3 className="text-xl font-cinzel font-bold text-amber-500 mb-4 flex items-center gap-2">
              <FileText size={20} /> {isEn ? 'Executive Summary' : 'ملخص تنفيذي'}
            </h3>
            <p className="text-gray-300 leading-relaxed italic">{result.summary}</p>
          </div>

          {/* DAX Measures */}
          <div className="grid gap-6">
            <h3 className="text-xl font-cinzel font-bold text-amber-500 flex items-center gap-2">
              <BarChart4 size={20} /> {isEn ? 'Recommended DAX Measures' : 'مقاييس DAX الموصى بها'}
            </h3>
            {result.suggestedDAX.map((dax, i) => (
              <div key={i} className="bg-neutral-900 p-6 rounded-xl border border-white/5 space-y-3 relative group">
                <button 
                  onClick={() => copyToClipboard(dax.formula, `dax-${i}`)}
                  className="absolute top-4 right-4 p-2 text-gray-500 hover:text-amber-500 transition-colors"
                >
                  {copied === `dax-${i}` ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                </button>
                <div className="font-bold text-white text-lg">{dax.name}</div>
                <div className="bg-black/50 p-4 rounded-lg font-mono text-sm text-amber-400 overflow-x-auto whitespace-pre">
                  {dax.formula}
                </div>
                <div className="text-gray-500 text-sm">{dax.description}</div>
              </div>
            ))}
          </div>

          {/* Visualization Recommendations */}
          <div className="bg-neutral-900 p-8 rounded-2xl border border-amber-900/20">
            <h3 className="text-xl font-cinzel font-bold text-amber-500 mb-6">{isEn ? 'Visualization Strategy' : 'استراتيجية التصور'}</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              {result.visualRecommendations.map((rec, i) => (
                <div key={i} className="bg-black/40 p-4 rounded-lg text-center border border-amber-500/10">
                  <div className="text-amber-500 font-bold mb-2">0{i+1}</div>
                  <div className="text-gray-300 font-medium">{rec}</div>
                </div>
              ))}
            </div>
          </div>

          <button 
            onClick={() => {setResult(null); setFile(null);}}
            className="w-full py-4 bg-white/5 border border-amber-900/30 text-amber-500 font-bold rounded-xl hover:bg-white/10 transition-all"
          >
            {isEn ? 'Analyze Another Dataset' : 'تحليل مجموعة بيانات أخرى'}
          </button>
        </div>
      )}
    </div>
  );
};

export default Analysis;
