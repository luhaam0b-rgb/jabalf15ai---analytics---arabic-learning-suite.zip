
import React, { useState } from 'react';
import { Menu, X, BrainCircuit, BookOpen, Award, BarChart3, LayoutDashboard, Globe, LogOut, User as UserIcon } from 'lucide-react';
import { AppLanguage, User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  user?: User | null;
  onLogout?: () => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  activeTab, 
  setActiveTab, 
  language, 
  setLanguage,
  user,
  onLogout
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const navItems = [
    { id: 'home', label: language === 'en' ? 'Home' : 'الرئيسية', icon: BrainCircuit },
    { id: 'analysis', label: language === 'en' ? 'AI Analysis' : 'تحليل الذكاء الاصطناعي', icon: BarChart3 },
    { id: 'academy', label: language === 'en' ? 'Academy' : 'الأكاديمية', icon: BookOpen },
    { id: 'certification', label: language === 'en' ? 'Certification' : 'الشهادات', icon: Award },
    { id: 'dashboard', label: language === 'en' ? 'Dashboard' : 'لوحة التحكم', icon: LayoutDashboard },
  ];

  const isRtl = language === AppLanguage.AR;

  return (
    <div className={`min-h-screen flex flex-col ${isRtl ? 'font-arabic' : ''}`} dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-black/90 border-b border-amber-900/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('home')}>
              <div className="w-10 h-10 gold-gradient rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(179,135,40,0.4)]">
                <BrainCircuit className="text-black" size={24} />
              </div>
              <span className="font-cinzel text-xl font-bold gold-text tracking-widest hidden sm:block">
                JABALF15AI
              </span>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-2 rtl:space-x-reverse">
              {user && navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                    activeTab === item.id
                      ? 'text-amber-400 bg-amber-900/20 shadow-[inset_0_0_10px_rgba(251,191,36,0.1)]'
                      : 'text-gray-400 hover:text-amber-200 hover:bg-white/5'
                  }`}
                >
                  <item.icon className="mr-2 ml-2" size={18} />
                  {item.label}
                </button>
              ))}
              
              <div className="h-6 w-px bg-amber-900/30 mx-2"></div>

              <button 
                onClick={() => setLanguage(language === AppLanguage.EN ? AppLanguage.AR : AppLanguage.EN)}
                className="p-2 text-amber-500 hover:bg-amber-900/20 rounded-full transition-colors"
              >
                <Globe size={18} />
              </button>

              {user && (
                <div className="relative">
                  <button 
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2 p-1.5 rounded-full bg-amber-900/20 border border-amber-900/30 hover:border-amber-500 transition-all ml-2"
                  >
                    <div className="w-7 h-7 gold-gradient rounded-full flex items-center justify-center text-black font-bold text-xs">
                      {user.name.charAt(0)}
                    </div>
                  </button>

                  {showUserMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-neutral-900 border border-amber-900/30 rounded-xl shadow-2xl py-2 z-[100] animate-in slide-in-from-top-2 duration-200">
                      <div className="px-4 py-2 border-b border-amber-900/10">
                        <div className="text-white font-bold text-sm truncate">{user.name}</div>
                        <div className="text-amber-500 text-[10px] font-cinzel tracking-widest">{user.rank}</div>
                      </div>
                      <button 
                        onClick={() => { setActiveTab('dashboard'); setShowUserMenu(false); }}
                        className="w-full text-left px-4 py-2 text-sm text-gray-400 hover:bg-amber-900/10 hover:text-white flex items-center gap-2"
                      >
                        <UserIcon size={16} /> {language === 'en' ? 'Profile' : 'الملف الشخصي'}
                      </button>
                      <button 
                        onClick={() => { onLogout?.(); setShowUserMenu(false); }}
                        className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-900/10 flex items-center gap-2"
                      >
                        <LogOut size={16} /> {language === 'en' ? 'Sign Out' : 'تسجيل الخروج'}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center gap-2">
              <button 
                onClick={() => setLanguage(language === AppLanguage.EN ? AppLanguage.AR : AppLanguage.EN)}
                className="p-2 text-amber-500 hover:bg-amber-900/20 rounded-full"
              >
                <Globe size={20} />
              </button>
              {user && (
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-amber-500 p-2"
                >
                  {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && user && (
          <div className="md:hidden bg-black/95 border-b border-amber-900/50">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`flex items-center w-full px-3 py-3 rounded-md text-base font-medium ${
                    activeTab === item.id ? 'text-amber-400 bg-amber-900/20' : 'text-gray-300'
                  }`}
                >
                  <item.icon className="mr-3 ml-3" size={20} />
                  {item.label}
                </button>
              ))}
              <div className="border-t border-amber-900/20 my-2 pt-2">
                <button 
                  onClick={() => onLogout?.()}
                  className="flex items-center w-full px-3 py-3 text-red-400 font-medium"
                >
                  <LogOut className="mr-3 ml-3" size={20} />
                  {language === 'en' ? 'Sign Out' : 'تسجيل الخروج'}
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-black border-t border-amber-900/30 py-8 text-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 gold-gradient rounded flex items-center justify-center">
            <BrainCircuit className="text-black" size={16} />
          </div>
          <p className="text-gray-500 text-sm font-cinzel tracking-widest uppercase">
            &copy; 2025 JABALF15AI Analytics & Education. Built for Excellence.
          </p>
          <div className="flex gap-4">
            <span className="text-amber-900/50 text-xs">Modular Architecture</span>
            <span className="text-amber-900/50 text-xs">AI Driven Insights</span>
            <span className="text-amber-900/50 text-xs">Secure Certification</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
